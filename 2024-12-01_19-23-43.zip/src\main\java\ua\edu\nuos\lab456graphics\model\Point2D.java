package ua.edu.nuos.lab456graphics.model;

public record Point2D(double x, double y) {
}
